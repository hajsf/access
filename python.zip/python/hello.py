# libraries:
import matplotlib.pyplot as plt
# sign is a symbol to make a comment in the Python editor
# Define the two fields as selected in Step 3 above: 
# define fields:
x = dataset.address1_city
y = dataset.estimatedvalue
# Define the chart:
# define visual:
plt.bar(x,y)
# Show the chart:
# show result
plt.show()